# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Smellybean::Application.config.secret_token = 'b5443e7f76ac3d7ad7012eec7fb58109a05fdfbd141dcaabab874d1800eec9c5d682d9b7d53219a253c2da5456706ef82dc1a14ba836e1bb65c0811a2e8d3b72'
